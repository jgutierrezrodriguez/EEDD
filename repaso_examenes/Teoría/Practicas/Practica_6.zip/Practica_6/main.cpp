/* 
 * File:   main.cpp
 * Author: Danymad92
 *
 * Created on 6 de noviembre de 2013, 18:06
 */

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <math.h>
#include <List>

#include "CodigoPost.h"
#include "DispCerrada.h"


using namespace std;

struct StructPost{
    string ciudad;
    list<CodigoPost> codigos;
    bool operator<(const StructPost &cp) const {
        return (ciudad < cp.ciudad);
    }
    friend ostream& operator <<(ostream& co, StructPost &a) {
        cout << a.ciudad;
        return co;
    }
    long hash(string palabra){
        unsigned long hash=5381;
        int c=0;
        while(c<palabra.length()){
            hash=((hash<<5)+hash)+palabra[c++];
        }
        return hash;
    }
};

bool esPrimo(int tam){
    for(int divisor=2;divisor<=sqrt(tam);divisor++){
        if (tam%divisor==0){
            return false;
        }
    }
    return true;
};

int nextPrim(int tam){
    
    do{
        tam++;
    }while(!esPrimo(tam));
    
    return tam;
};

void cargarCsv(string cadena,int &Zipcode,string &ZipCodeType,string &City,string &State,string &LocationType,float &Lat,float &Long,string &Location,bool &Decommisioned,int &TaxReturnsFiled,int &EstimatedPopulation,int &TotalWages){
    stringstream ss;
    ss<<cadena;
    //string palabra;
    ss.ignore(1);
    ss>>Zipcode;
    ss.ignore(1);
    ss.ignore(1);
    ss.ignore(1);
    getline(ss>>ws,ZipCodeType,'"');
    ss.ignore(1);
    ss.ignore(1);
    getline(ss>>ws,City,'"');
    ss.ignore(1);
    ss.ignore(1);
    getline(ss>>ws,State,'"');
    ss.ignore(1);
    ss.ignore(1);
    getline(ss>>ws,LocationType,'"');
    ss.ignore(1);
    ss>>Lat;
    ss.ignore(1);
    ss>>Long;
    ss.ignore(1);
    ss.ignore(1);
    getline(ss>>ws,Location,'"');
    ss.ignore(1);
    ss.ignore(1);
    ss>>Decommisioned;
    ss.ignore(1);
    ss.ignore(1);
    ss.ignore(1);
    ss>>TaxReturnsFiled;
    ss.ignore(1);
    ss>>EstimatedPopulation;
    ss.ignore(1);
    ss>>TotalWages;
}

void leer(DispCerrada<StructPost> &tabla){
    StructPost *encontrado=NULL;
    int col=0;
    int Zipcode,TaxReturnsFiled,EstimatedPopulation,TotalWages;
    float Lat,Long;
    string cadena,ZipCodeType,City,State,LocationType,Location,basura;
    bool Decommisioned;
    ifstream fichero("free-zipcode-database-Primary.csv");
    if(fichero){
        cout<<"Leyendo el fichero..."<<endl;
        getline(fichero>>ws,basura);
        while(getline(fichero>>ws,cadena)){
            StructPost s;
            cargarCsv(cadena,Zipcode,ZipCodeType,City,State,LocationType,Lat,Long,Location,Decommisioned,TaxReturnsFiled,EstimatedPopulation,TotalWages);
            s.ciudad=City;
            CodigoPost c(Zipcode,ZipCodeType,State,LocationType,Lat,Long,Location,Decommisioned,TaxReturnsFiled,EstimatedPopulation,TotalWages);
            encontrado=tabla.busqueda(s.hash(s.ciudad),s);
            if(encontrado){
                encontrado->codigos.push_back(c);
            }else{   
                s.codigos.push_back(c);
                tabla.insercion(s.hash(s.ciudad),s);
            }
        }
        cout<<"Fichero leido"<<endl;
        //cout<<"Colisiones: "<<col<<endl;
    }
}

int main(int argc, char** argv) {
    
    int col=0;
    unsigned tamTablaDisp=24700;
    
    float alfa=18758.0/tamTablaDisp;
    cout<<"Valor de alfa: "<<alfa<<endl;
    
    if(!esPrimo(tamTablaDisp+tamTablaDisp*(1-alfa))){
        tamTablaDisp=nextPrim(tamTablaDisp+tamTablaDisp*(1-alfa));
    }
    
    DispCerrada<StructPost> tabla(tamTablaDisp);
    cout<<"tam: "<<tamTablaDisp<<endl;
    
    string leida;
    StructPost *encontrado=NULL;
    leer(tabla);
    do{
        cout<<"Introduzca una ciudad: " <<endl;
        getline(cin>>ws,leida);
        StructPost o;
        o.ciudad=leida;
        encontrado=tabla.busqueda(o.hash(o.ciudad),o);
        if(encontrado){
            list<CodigoPost>::iterator it=encontrado->codigos.begin();
            while(it!=encontrado->codigos.end()){
                cout<<it->GetZipcode()<<endl;
                it++;
            }
        }else{
            cout<<"No encontrado"<<endl;
        }
    }while(leida!="salir");
    
    cout<<"Tamano tabla hash: "<<tabla.getTam()<<endl;
    
    
    
    return 0;
    
}

