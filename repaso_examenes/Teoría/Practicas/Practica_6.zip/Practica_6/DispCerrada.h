/* 
 * File:   DispCerrada.h
 * Author: Miguel Angel
 *
 * Created on 20 de noviembre de 2013, 8:16
 */

#ifndef DISPCERRADA_H
#define	DISPCERRADA_H

#include "Estructuras.h"
#include <vector>

using namespace std;

template<class T>
class Entrada{
public:
  long clave;
  T dato;
  char estado;
  Entrada(long aClave, T aDato):clave(aClave),dato(aDato),estado(false){};
  Entrada():estado(){};
};


template<class T>
class DispCerrada {
private:
    int ele,max,tot;
    vector<Entrada<T> > tabla;
public:
    DispCerrada(int tam);
    DispCerrada(const DispCerrada& orig);
    virtual ~DispCerrada(){};
    bool insercion(long clav,const T &dat);
    T* busqueda(long clav,const T &dato);
    int getTam() const;
    T& obtenerEntrada(long i);
    int getTot() const;
    int getMax() const;
    int getEle() const;
};

template<class T>
DispCerrada<T>::DispCerrada(int tam):max(0),tot(0),ele(0){
    tabla.resize(tam,Entrada<T>());
}



template<class T>
bool DispCerrada<T>::insercion(long clav,const T &dat){
    unsigned int pos=clav%tabla.size();//Posicion Natural
    
    int i=0;
    while(tabla[pos].estado=='$' && tabla[pos].clave!=clav){
        pos=(pos+i*i)%tabla.size();
        i++;
    }

    //cout<<max<<endl;
    if(tabla[pos].clave!=clav){
        tabla[pos].dato=dat;
        tabla[pos].clave=clav;
        tabla[pos].estado='$';
        ele++;
        if(max<i-1) max=i-1;
        tot+=i;
        return true;
    }else{
        return false;
    }
    
};

template<class T>
int DispCerrada<T>::getTot() const {
    return tot;
}

template<class T>
int DispCerrada<T>::getMax() const {
    return max;
}

template<class T>
int DispCerrada<T>::getEle() const {
    return ele;
}

template<class T>
T *DispCerrada<T>::busqueda(long clav,const T &dato){ 
    unsigned int pos=clav%tabla.size();
    int i=1;

    while(tabla[pos].estado=='$'){
        if(tabla[pos].clave==clav){
            return &tabla[pos].dato;
        }else{
            pos=(pos+(i*i))%tabla.size();
            i++;
        }
    }
    return NULL;
};

template<class T>
int DispCerrada<T>::getTam() const{
    return tabla.size();
}

template<class T>
T& DispCerrada<T>::obtenerEntrada(long i){
    return tabla[i].dato;
}

#endif	/* DISPCERRADA_H */

