//
//  particula.h
//  particulas3D
//
//  Created by Antonio Jesús Rueda Ruiz on 17/10/13.
//

#ifndef __particulas3D__particula__
#define __particulas3D__particula__

class Particula {
    int x, y, z; //posición dentro de la matriz, 0<=(x,y,z)<n
    int masa;

public:
    Particula (int xx, int yy, int zz) : x(xx), y(yy), z(zz), masa(random() % 20) {}
    
    ~Particula(){}
    
    int getMasa() { return masa; }
    
    void aumentaMasa(int masa) {
        this->masa = masa;
    }
    
    void actualizaPosicion(int xx, int yy, int zz) {
        x += xx;
        y += yy;
        z += zz;
    }
    
    int leerX() { return x; }
    int leerY() { return y; }
    int leerZ() { return z; }
};

#endif /* defined(__particulas3D__particula__) */
